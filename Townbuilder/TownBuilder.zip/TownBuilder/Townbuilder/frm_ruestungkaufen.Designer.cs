﻿
namespace Townbuilder
{
    partial class frm_ruestungkaufen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_geld = new System.Windows.Forms.Label();
            this.lbl_r3 = new System.Windows.Forms.Label();
            this.pbx_r3 = new System.Windows.Forms.PictureBox();
            this.lbl_r2 = new System.Windows.Forms.Label();
            this.pbx_r2 = new System.Windows.Forms.PictureBox();
            this.lbl_r1 = new System.Windows.Forms.Label();
            this.pbx_r1 = new System.Windows.Forms.PictureBox();
            this.pbx_r4 = new System.Windows.Forms.PictureBox();
            this.lbl_r4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r4)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_geld
            // 
            this.lbl_geld.AutoSize = true;
            this.lbl_geld.Location = new System.Drawing.Point(678, 22);
            this.lbl_geld.Name = "lbl_geld";
            this.lbl_geld.Size = new System.Drawing.Size(38, 17);
            this.lbl_geld.TabIndex = 17;
            this.lbl_geld.Text = "Geld";
            // 
            // lbl_r3
            // 
            this.lbl_r3.AutoSize = true;
            this.lbl_r3.Location = new System.Drawing.Point(644, 436);
            this.lbl_r3.Name = "lbl_r3";
            this.lbl_r3.Size = new System.Drawing.Size(16, 17);
            this.lbl_r3.TabIndex = 16;
            this.lbl_r3.Text = "0";
            // 
            // pbx_r3
            // 
            this.pbx_r3.BackColor = System.Drawing.Color.DarkBlue;
            this.pbx_r3.Location = new System.Drawing.Point(536, 78);
            this.pbx_r3.Name = "pbx_r3";
            this.pbx_r3.Size = new System.Drawing.Size(260, 326);
            this.pbx_r3.TabIndex = 15;
            this.pbx_r3.TabStop = false;
            this.pbx_r3.Click += new System.EventHandler(this.pbx_r3_Click);
            // 
            // lbl_r2
            // 
            this.lbl_r2.AutoSize = true;
            this.lbl_r2.Location = new System.Drawing.Point(344, 436);
            this.lbl_r2.Name = "lbl_r2";
            this.lbl_r2.Size = new System.Drawing.Size(16, 17);
            this.lbl_r2.TabIndex = 14;
            this.lbl_r2.Text = "0";
            // 
            // pbx_r2
            // 
            this.pbx_r2.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.pbx_r2.Location = new System.Drawing.Point(270, 78);
            this.pbx_r2.Name = "pbx_r2";
            this.pbx_r2.Size = new System.Drawing.Size(260, 326);
            this.pbx_r2.TabIndex = 13;
            this.pbx_r2.TabStop = false;
            this.pbx_r2.Click += new System.EventHandler(this.pbx_r2_Click);
            // 
            // lbl_r1
            // 
            this.lbl_r1.AutoSize = true;
            this.lbl_r1.Location = new System.Drawing.Point(113, 436);
            this.lbl_r1.Name = "lbl_r1";
            this.lbl_r1.Size = new System.Drawing.Size(16, 17);
            this.lbl_r1.TabIndex = 12;
            this.lbl_r1.Text = "0";
            // 
            // pbx_r1
            // 
            this.pbx_r1.BackColor = System.Drawing.Color.DarkRed;
            this.pbx_r1.Location = new System.Drawing.Point(4, 78);
            this.pbx_r1.Name = "pbx_r1";
            this.pbx_r1.Size = new System.Drawing.Size(260, 326);
            this.pbx_r1.TabIndex = 11;
            this.pbx_r1.TabStop = false;
            this.pbx_r1.Click += new System.EventHandler(this.pbx_r1_Click);
            // 
            // pbx_r4
            // 
            this.pbx_r4.BackColor = System.Drawing.Color.DarkOrange;
            this.pbx_r4.Location = new System.Drawing.Point(802, 78);
            this.pbx_r4.Name = "pbx_r4";
            this.pbx_r4.Size = new System.Drawing.Size(260, 326);
            this.pbx_r4.TabIndex = 18;
            this.pbx_r4.TabStop = false;
            this.pbx_r4.Click += new System.EventHandler(this.pbx_r4_Click);
            // 
            // lbl_r4
            // 
            this.lbl_r4.AutoSize = true;
            this.lbl_r4.Location = new System.Drawing.Point(937, 436);
            this.lbl_r4.Name = "lbl_r4";
            this.lbl_r4.Size = new System.Drawing.Size(16, 17);
            this.lbl_r4.TabIndex = 19;
            this.lbl_r4.Text = "0";
            // 
            // frm_ruestungkaufen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 489);
            this.Controls.Add(this.lbl_r4);
            this.Controls.Add(this.pbx_r4);
            this.Controls.Add(this.lbl_geld);
            this.Controls.Add(this.lbl_r3);
            this.Controls.Add(this.pbx_r3);
            this.Controls.Add(this.lbl_r2);
            this.Controls.Add(this.pbx_r2);
            this.Controls.Add(this.lbl_r1);
            this.Controls.Add(this.pbx_r1);
            this.Name = "frm_ruestungkaufen";
            this.Text = "frm_ruestungkaufen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_ruestungkaufen_FormClosing);
            this.Load += new System.EventHandler(this.frm_ruestungkaufen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_r4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_geld;
        private System.Windows.Forms.Label lbl_r3;
        private System.Windows.Forms.PictureBox pbx_r3;
        private System.Windows.Forms.Label lbl_r2;
        private System.Windows.Forms.PictureBox pbx_r2;
        private System.Windows.Forms.Label lbl_r1;
        private System.Windows.Forms.PictureBox pbx_r1;
        private System.Windows.Forms.PictureBox pbx_r4;
        private System.Windows.Forms.Label lbl_r4;
    }
}