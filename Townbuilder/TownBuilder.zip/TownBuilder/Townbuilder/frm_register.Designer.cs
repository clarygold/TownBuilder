﻿namespace Townbuilder
{
    partial class frm_register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_passwordagain = new System.Windows.Forms.TextBox();
            this.pbx_bild9 = new System.Windows.Forms.PictureBox();
            this.pbx_bild8 = new System.Windows.Forms.PictureBox();
            this.pbx_bild7 = new System.Windows.Forms.PictureBox();
            this.pbx_bild6 = new System.Windows.Forms.PictureBox();
            this.pbx_bild5 = new System.Windows.Forms.PictureBox();
            this.pbx_bild4 = new System.Windows.Forms.PictureBox();
            this.pbx_bild3 = new System.Windows.Forms.PictureBox();
            this.pbx_bild2 = new System.Windows.Forms.PictureBox();
            this.pbx_bild1 = new System.Windows.Forms.PictureBox();
            this.pbx_back = new System.Windows.Forms.PictureBox();
            this.pb_loginpress = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_loginpress)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_username
            // 
            this.tb_username.BackColor = System.Drawing.Color.Black;
            this.tb_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.tb_username.ForeColor = System.Drawing.Color.White;
            this.tb_username.Location = new System.Drawing.Point(209, 249);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(390, 31);
            this.tb_username.TabIndex = 1;
            // 
            // tb_password
            // 
            this.tb_password.BackColor = System.Drawing.Color.Black;
            this.tb_password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.tb_password.ForeColor = System.Drawing.Color.White;
            this.tb_password.Location = new System.Drawing.Point(209, 355);
            this.tb_password.Name = "tb_password";
            this.tb_password.PasswordChar = '*';
            this.tb_password.Size = new System.Drawing.Size(390, 31);
            this.tb_password.TabIndex = 2;
            // 
            // tb_passwordagain
            // 
            this.tb_passwordagain.BackColor = System.Drawing.Color.Black;
            this.tb_passwordagain.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_passwordagain.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.tb_passwordagain.ForeColor = System.Drawing.Color.White;
            this.tb_passwordagain.Location = new System.Drawing.Point(209, 458);
            this.tb_passwordagain.Name = "tb_passwordagain";
            this.tb_passwordagain.PasswordChar = '*';
            this.tb_passwordagain.Size = new System.Drawing.Size(390, 31);
            this.tb_passwordagain.TabIndex = 3;
            // 
            // pbx_bild9
            // 
            this.pbx_bild9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild9.Location = new System.Drawing.Point(956, 496);
            this.pbx_bild9.Name = "pbx_bild9";
            this.pbx_bild9.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild9.TabIndex = 14;
            this.pbx_bild9.TabStop = false;
            this.pbx_bild9.Click += new System.EventHandler(this.pbx_bild9_Click);
            // 
            // pbx_bild8
            // 
            this.pbx_bild8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild8.Location = new System.Drawing.Point(843, 496);
            this.pbx_bild8.Name = "pbx_bild8";
            this.pbx_bild8.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild8.TabIndex = 13;
            this.pbx_bild8.TabStop = false;
            this.pbx_bild8.Click += new System.EventHandler(this.pbx_bild8_Click);
            // 
            // pbx_bild7
            // 
            this.pbx_bild7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild7.Location = new System.Drawing.Point(730, 496);
            this.pbx_bild7.Name = "pbx_bild7";
            this.pbx_bild7.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild7.TabIndex = 12;
            this.pbx_bild7.TabStop = false;
            this.pbx_bild7.Click += new System.EventHandler(this.pbx_bild7_Click);
            // 
            // pbx_bild6
            // 
            this.pbx_bild6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild6.Location = new System.Drawing.Point(956, 362);
            this.pbx_bild6.Name = "pbx_bild6";
            this.pbx_bild6.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild6.TabIndex = 11;
            this.pbx_bild6.TabStop = false;
            this.pbx_bild6.Click += new System.EventHandler(this.pbx_bild6_Click);
            // 
            // pbx_bild5
            // 
            this.pbx_bild5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild5.Location = new System.Drawing.Point(843, 363);
            this.pbx_bild5.Name = "pbx_bild5";
            this.pbx_bild5.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild5.TabIndex = 10;
            this.pbx_bild5.TabStop = false;
            this.pbx_bild5.Click += new System.EventHandler(this.pbx_bild5_Click);
            // 
            // pbx_bild4
            // 
            this.pbx_bild4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild4.Location = new System.Drawing.Point(730, 362);
            this.pbx_bild4.Name = "pbx_bild4";
            this.pbx_bild4.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild4.TabIndex = 9;
            this.pbx_bild4.TabStop = false;
            this.pbx_bild4.Click += new System.EventHandler(this.pbx_bild4_Click);
            // 
            // pbx_bild3
            // 
            this.pbx_bild3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild3.Location = new System.Drawing.Point(956, 227);
            this.pbx_bild3.Name = "pbx_bild3";
            this.pbx_bild3.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild3.TabIndex = 8;
            this.pbx_bild3.TabStop = false;
            this.pbx_bild3.Click += new System.EventHandler(this.pbx_bild3_Click);
            // 
            // pbx_bild2
            // 
            this.pbx_bild2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild2.Location = new System.Drawing.Point(843, 228);
            this.pbx_bild2.Name = "pbx_bild2";
            this.pbx_bild2.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild2.TabIndex = 7;
            this.pbx_bild2.TabStop = false;
            this.pbx_bild2.Click += new System.EventHandler(this.pbx_bild2_Click);
            // 
            // pbx_bild1
            // 
            this.pbx_bild1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_bild1.Location = new System.Drawing.Point(730, 229);
            this.pbx_bild1.Name = "pbx_bild1";
            this.pbx_bild1.Size = new System.Drawing.Size(107, 127);
            this.pbx_bild1.TabIndex = 6;
            this.pbx_bild1.TabStop = false;
            this.pbx_bild1.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pbx_back
            // 
            this.pbx_back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_back.Image = global::Townbuilder.Properties.Resources.Backbtn;
            this.pbx_back.Location = new System.Drawing.Point(12, 12);
            this.pbx_back.Name = "pbx_back";
            this.pbx_back.Size = new System.Drawing.Size(70, 70);
            this.pbx_back.TabIndex = 5;
            this.pbx_back.TabStop = false;
            this.pbx_back.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pb_loginpress
            // 
            this.pb_loginpress.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pb_loginpress.Image = global::Townbuilder.Properties.Resources.RegisterBtn;
            this.pb_loginpress.Location = new System.Drawing.Point(206, 516);
            this.pb_loginpress.Name = "pb_loginpress";
            this.pb_loginpress.Size = new System.Drawing.Size(409, 80);
            this.pb_loginpress.TabIndex = 4;
            this.pb_loginpress.TabStop = false;
            this.pb_loginpress.Click += new System.EventHandler(this.pb_loginpress_Click);
            // 
            // frm_register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Townbuilder.Properties.Resources.RegisterMenu;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.pbx_bild9);
            this.Controls.Add(this.pbx_bild8);
            this.Controls.Add(this.pbx_bild7);
            this.Controls.Add(this.pbx_bild6);
            this.Controls.Add(this.pbx_bild5);
            this.Controls.Add(this.pbx_bild4);
            this.Controls.Add(this.pbx_bild3);
            this.Controls.Add(this.pbx_bild2);
            this.Controls.Add(this.pbx_bild1);
            this.Controls.Add(this.pbx_back);
            this.Controls.Add(this.pb_loginpress);
            this.Controls.Add(this.tb_passwordagain);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_username);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frm_register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_register";
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_bild1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_loginpress)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_passwordagain;
        private System.Windows.Forms.PictureBox pb_loginpress;
        private System.Windows.Forms.PictureBox pbx_back;
        private System.Windows.Forms.PictureBox pbx_bild1;
        private System.Windows.Forms.PictureBox pbx_bild2;
        private System.Windows.Forms.PictureBox pbx_bild3;
        private System.Windows.Forms.PictureBox pbx_bild6;
        private System.Windows.Forms.PictureBox pbx_bild5;
        private System.Windows.Forms.PictureBox pbx_bild4;
        private System.Windows.Forms.PictureBox pbx_bild9;
        private System.Windows.Forms.PictureBox pbx_bild8;
        private System.Windows.Forms.PictureBox pbx_bild7;
    }
}