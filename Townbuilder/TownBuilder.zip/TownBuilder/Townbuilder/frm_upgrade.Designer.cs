﻿
namespace Townbuilder
{
    partial class frm_upgrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pbx_wacheplus = new System.Windows.Forms.PictureBox();
            this.pbx_waffeplus = new System.Windows.Forms.PictureBox();
            this.pbx_ruestungplus = new System.Windows.Forms.PictureBox();
            this.pbx_stadtplus = new System.Windows.Forms.PictureBox();
            this.pbx_stadtreparieren = new System.Windows.Forms.PictureBox();
            this.lbl_geld = new System.Windows.Forms.Label();
            this.pbx_back = new System.Windows.Forms.PictureBox();
            this.lbl_waffekosten = new System.Windows.Forms.Label();
            this.lbl_ruestungkosten = new System.Windows.Forms.Label();
            this.lbl_stadtkosten = new System.Windows.Forms.Label();
            this.lbl_wachekosten = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_wacheplus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_waffeplus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_ruestungplus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_stadtplus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_stadtreparieren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 233);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wache:";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Stadt:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(85, 299);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Rüstung:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Waffe:";
            // 
            // pbx_wacheplus
            // 
            this.pbx_wacheplus.BackColor = System.Drawing.Color.ForestGreen;
            this.pbx_wacheplus.Location = new System.Drawing.Point(167, 223);
            this.pbx_wacheplus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbx_wacheplus.Name = "pbx_wacheplus";
            this.pbx_wacheplus.Size = new System.Drawing.Size(136, 27);
            this.pbx_wacheplus.TabIndex = 4;
            this.pbx_wacheplus.TabStop = false;
            this.pbx_wacheplus.Visible = false;
            this.pbx_wacheplus.Click += new System.EventHandler(this.pbx_wacheplus_Click);
            // 
            // pbx_waffeplus
            // 
            this.pbx_waffeplus.BackColor = System.Drawing.Color.ForestGreen;
            this.pbx_waffeplus.Location = new System.Drawing.Point(167, 321);
            this.pbx_waffeplus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbx_waffeplus.Name = "pbx_waffeplus";
            this.pbx_waffeplus.Size = new System.Drawing.Size(136, 27);
            this.pbx_waffeplus.TabIndex = 5;
            this.pbx_waffeplus.TabStop = false;
            this.pbx_waffeplus.Click += new System.EventHandler(this.pbx_waffeplus_Click);
            // 
            // pbx_ruestungplus
            // 
            this.pbx_ruestungplus.BackColor = System.Drawing.Color.ForestGreen;
            this.pbx_ruestungplus.Location = new System.Drawing.Point(167, 289);
            this.pbx_ruestungplus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbx_ruestungplus.Name = "pbx_ruestungplus";
            this.pbx_ruestungplus.Size = new System.Drawing.Size(136, 27);
            this.pbx_ruestungplus.TabIndex = 6;
            this.pbx_ruestungplus.TabStop = false;
            this.pbx_ruestungplus.Click += new System.EventHandler(this.pbx_ruestungplus_Click);
            // 
            // pbx_stadtplus
            // 
            this.pbx_stadtplus.BackColor = System.Drawing.Color.ForestGreen;
            this.pbx_stadtplus.Location = new System.Drawing.Point(167, 256);
            this.pbx_stadtplus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbx_stadtplus.Name = "pbx_stadtplus";
            this.pbx_stadtplus.Size = new System.Drawing.Size(136, 27);
            this.pbx_stadtplus.TabIndex = 7;
            this.pbx_stadtplus.TabStop = false;
            this.pbx_stadtplus.Click += new System.EventHandler(this.pbx_stadtplus_Click);
            // 
            // pbx_stadtreparieren
            // 
            this.pbx_stadtreparieren.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_stadtreparieren.Location = new System.Drawing.Point(308, 256);
            this.pbx_stadtreparieren.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbx_stadtreparieren.Name = "pbx_stadtreparieren";
            this.pbx_stadtreparieren.Size = new System.Drawing.Size(136, 27);
            this.pbx_stadtreparieren.TabIndex = 8;
            this.pbx_stadtreparieren.TabStop = false;
            this.pbx_stadtreparieren.Visible = false;
            // 
            // lbl_geld
            // 
            this.lbl_geld.AutoSize = true;
            this.lbl_geld.Location = new System.Drawing.Point(665, 49);
            this.lbl_geld.Name = "lbl_geld";
            this.lbl_geld.Size = new System.Drawing.Size(42, 17);
            this.lbl_geld.TabIndex = 9;
            this.lbl_geld.Text = "Geld:";
            // 
            // pbx_back
            // 
            this.pbx_back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbx_back.Image = global::Townbuilder.Properties.Resources.Backbtn;
            this.pbx_back.Location = new System.Drawing.Point(44, 27);
            this.pbx_back.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pbx_back.Name = "pbx_back";
            this.pbx_back.Size = new System.Drawing.Size(93, 86);
            this.pbx_back.TabIndex = 10;
            this.pbx_back.TabStop = false;
            this.pbx_back.Click += new System.EventHandler(this.pbx_back_Click);
            // 
            // lbl_waffekosten
            // 
            this.lbl_waffekosten.AutoSize = true;
            this.lbl_waffekosten.Location = new System.Drawing.Point(176, 331);
            this.lbl_waffekosten.Name = "lbl_waffekosten";
            this.lbl_waffekosten.Size = new System.Drawing.Size(0, 17);
            this.lbl_waffekosten.TabIndex = 14;
            // 
            // lbl_ruestungkosten
            // 
            this.lbl_ruestungkosten.AutoSize = true;
            this.lbl_ruestungkosten.Location = new System.Drawing.Point(176, 298);
            this.lbl_ruestungkosten.Name = "lbl_ruestungkosten";
            this.lbl_ruestungkosten.Size = new System.Drawing.Size(0, 17);
            this.lbl_ruestungkosten.TabIndex = 13;
            // 
            // lbl_stadtkosten
            // 
            this.lbl_stadtkosten.AutoSize = true;
            this.lbl_stadtkosten.Location = new System.Drawing.Point(176, 265);
            this.lbl_stadtkosten.Name = "lbl_stadtkosten";
            this.lbl_stadtkosten.Size = new System.Drawing.Size(0, 17);
            this.lbl_stadtkosten.TabIndex = 12;
            // 
            // lbl_wachekosten
            // 
            this.lbl_wachekosten.AutoSize = true;
            this.lbl_wachekosten.Location = new System.Drawing.Point(176, 232);
            this.lbl_wachekosten.Name = "lbl_wachekosten";
            this.lbl_wachekosten.Size = new System.Drawing.Size(0, 17);
            this.lbl_wachekosten.TabIndex = 11;
            this.lbl_wachekosten.Visible = false;
            // 
            // frm_upgrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1707, 886);
            this.Controls.Add(this.lbl_waffekosten);
            this.Controls.Add(this.lbl_ruestungkosten);
            this.Controls.Add(this.lbl_stadtkosten);
            this.Controls.Add(this.lbl_wachekosten);
            this.Controls.Add(this.pbx_back);
            this.Controls.Add(this.lbl_geld);
            this.Controls.Add(this.pbx_stadtreparieren);
            this.Controls.Add(this.pbx_stadtplus);
            this.Controls.Add(this.pbx_ruestungplus);
            this.Controls.Add(this.pbx_waffeplus);
            this.Controls.Add(this.pbx_wacheplus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frm_upgrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_upgrade";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_upgrade_FormClosing);
            this.Load += new System.EventHandler(this.frm_upgrade_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_wacheplus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_waffeplus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_ruestungplus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_stadtplus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_stadtreparieren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbx_wacheplus;
        private System.Windows.Forms.PictureBox pbx_waffeplus;
        private System.Windows.Forms.PictureBox pbx_ruestungplus;
        private System.Windows.Forms.PictureBox pbx_stadtplus;
        private System.Windows.Forms.PictureBox pbx_stadtreparieren;
        private System.Windows.Forms.Label lbl_geld;
        private System.Windows.Forms.PictureBox pbx_back;
        private System.Windows.Forms.Label lbl_waffekosten;
        private System.Windows.Forms.Label lbl_ruestungkosten;
        private System.Windows.Forms.Label lbl_stadtkosten;
        private System.Windows.Forms.Label lbl_wachekosten;
    }
}